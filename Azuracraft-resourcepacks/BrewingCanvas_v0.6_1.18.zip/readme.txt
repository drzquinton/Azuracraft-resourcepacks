Version .6
by Rootbeerdrinker1
12/11/2021
--------------------------------------------------------

Directory Guide:
"/assets/minecraft/textures/painting" - Vanilla
"/assets/paintings/textures/painting" - Paintings++ Mod
--------------------------------------------------------

To swap out the frames for the alternative ones (VANILLA):

1. Extract this zip folder into your resourcepack folder

2. Copy the frame you want to use from the Paintings++ directory

3. Remove the unwanted frames and drag in the desired ones

4. Set the names to one of the following; courbet, creebet, pool, sea, sunset
	Or use the name "fighters" for the 4x2 block painting
 	- There cant be multiple frames with the same name!


-------------------------------------------------------------------------------
If you downloaded the default pack then it starts off with replacing only one vanilla painting with the dark oak frame.

The other unused frames are gold, blackstone, bamboo, crying obsidian, dark prismarine, dirt, gold, lapis, nether wart, oak, copper and purpur.

If you have the Paintings++ mod then all frames are usable with the wonderful gui.


-------------------------------------------------------------------------------
Plans for optifine

Whenever support for random textures and/or overlays gets re-added for paintings I will make a much better pack with all painting frames available without replacing vanilla paintings.